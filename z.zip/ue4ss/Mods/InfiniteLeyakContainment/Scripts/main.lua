--[[
    Author: Igromanru
    Date: 16.10.2024
    Mod Name: Infinite Leyak Containment
]]

------------------------------
-- Don't change code below --
------------------------------
ModName = "InfiniteLeyakContainment"
ModVersion = "1.2.0"
DebugMode = true
IsModEnabled = true

local function ModInfoAsPrefix()
    return "["..ModName.." v"..ModVersion.."] "
end

print(ModInfoAsPrefix().."Starting mod initialization\n")

local function NewDayUpdate(Context)
    local leyakContainment = Context:get() ---@type ADeployed_LeyakContainment_C

    if IsModEnabled and leyakContainment.ContainsLeyak:GetComparisonIndex() > 0 then
        local stability = leyakContainment['Stability Level']
        local maxStability = leyakContainment.MaxStability
        local difference =  maxStability - stability

        if difference > 0 and leyakContainment.CurrentStabilisingFoodRowName:GetComparisonIndex() > 0 then
            leyakContainment:ServerUpdateStabilityLevel(difference, leyakContainment.CurrentStabilisingFoodRowName)
        end
        if DebugMode then
            print(ModInfoAsPrefix().."New Stability Level: "..leyakContainment['Stability Level']..'\n')
        end
    end
end

ExecuteInGameThread(function()
    print(ModInfoAsPrefix().."Initializing hooks\n")
    LoadAsset("/Game/Blueprints/DeployedObjects/Furniture/Deployed_LeyakContainment.Deployed_LeyakContainment_C")
    RegisterHook("/Game/Blueprints/DeployedObjects/Furniture/Deployed_LeyakContainment.Deployed_LeyakContainment_C:NewDayUpdate", NewDayUpdate)
    print(ModInfoAsPrefix().."Hooks initialized\n")
end)

print(ModInfoAsPrefix().."Mod loaded successfully\n")
