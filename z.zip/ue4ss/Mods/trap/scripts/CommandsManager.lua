local AFUtils = require("AFUtils.AFUtils")
local LinearColors = require("AFUtils.BaseUtils.LinearColors")
require("Settings")
local SettingsManager = require("SettingsManager")
local Skills = require("Skills")
local LocationsManager = require("LocationsManager")
local WeatherManager = require("WeatherManager")
local PlayersManager = require("PlayersManager")
TrapKrasue
LogDebug("CommandLine:", GetKismetSystemLibrary():GetCommandLine():ToString())
LogInfo("IsDedicatedServer:", AFUtils.IsDedicatedServer())

---Write to lua console and the OutputDevice
---@param OutputDevice FOutputDevice
---@param Message string
local function WriteToConsole(OutputDevice, Message)
    LogInfo(Message)
    if OutputDevice then
        OutputDevice:Log(Message)
    end
end

---Calls WriteToConsole with orefix "[Error] "
---@param OutputDevice FOutputDevice
---@param Message string
local function WriteErrorToConsole(OutputDevice, Message)
    if type(Message) ~= "string" then
        error("Invalid type of parameter \"Message\", it has to be a string")
    end

    WriteToConsole(OutputDevice, "[Error] " .. Message)
end

---Write to lua console and the OutputDevice only in DebugMode
---@param OutputDevice FOutputDevice
---@param Message string
local function WriteToConsoleDebug(OutputDevice, Message)
    if DebugMode then
        LogInfo(Message)
        if OutputDevice then
            OutputDevice:Log(Message)
        end
    end
end

---Returns true if IsDedicatedServer and error was printed
---@param OutputDevice table
---@return boolean IsDedicatedServer
local function CheckAndLogDedicatedServerCommandSupport(OutputDevice)
    if AFUtils.IsDedicatedServer() then
        WriteErrorToConsole(OutputDevice, "The command is not supported on Dedicated Server!")
        return true
    end
    return false
end

---Returns true if the local player has no authority
---@param OutputDevice table
---@return boolean NoAuthority
local function CheckHasNoAuthority(OutputDevice)
    if not IsHost() then
        WriteErrorToConsole(OutputDevice, "You don't have the authority to use this command!")
        return true
    end
    return false
end

---@alias CommandFunction fun(self: CommandStruct, OutputDevice: FOutputDevice, Parameters: table): boolean

---@class CommandParam
---@field Name string
---@field ValidType string # Type name, see: https://www.lua.org/pil/2.html
---@field Description string?
---@field Required boolean
---@field ValidValues string[]?
local CommandParam = {}

---@class CommandStruct
---@field Aliases table<string>|string
---@field Name string
---@field Description string
---@field Parameters CommandParam[]|nil
---@field Function CommandFunction?
---@field SettingName string?
local CommandStruct = {}

---@type CommandStruct[]
local CommandsArray = {}

---@type { [string]: CommandStruct }
local CommandsMap = {}

---@param Name string # Name or alias
---@param Command CommandStruct
local function MapCommand(Name, Command)
    CommandsMap[string.lower(Name)] = Command
end

---@param Name string # Name or alias
---@return CommandStruct?
local function GetCommand(Name)
    return CommandsMap[string.lower(Name)]
end

---Debug logs all infomations about a CommandParam
---@param Param CommandParam
---@param Prefix string?
local function LogDebugCommandParam(Param, Prefix)
    if not Param or not Param.ValidType then return end
    Prefix = Prefix or ""

    LogDebug(Prefix .. "Parameter: Name: " .. Param.Name .. ", Required: " .. tostring(Param.Required) .. ", ValidType: " .. Param.ValidType .. ", Description: " .. tostring(Param.Description) .. ", ValidValues: " .. ArrayToString(Param.ValidValues))
end


---Debug logs all infomations about a CommandStruct
---@param Command CommandStruct
---@param Prefix string?
local function LogDebugCommandStruct(Command, Prefix)
    if not Command or not Command.Name then return end
    Prefix = Prefix or ""

    LogDebug(Prefix .."LogDebugCommandStruct:")
    LogDebug("Name: " .. Command.Name .. ", Aliases: " .. ArrayToString(Command.Aliases) .. ", Description: " .. Command.Description .. ", Parameters type: " .. type(Command.Parameters) .. ", Function type: " .. type(Command.Function))
    if Command.Parameters then
        for index, value in ipairs(Command.Parameters) do
            LogDebugCommandParam(value, "  " .. index .. ": ")
        end
    end
    LogDebug("---")
end

---@param StringArray string[]|string
---@param Seperator string? # Default: " | "
---@param WrapperLeft string? # Default: ""
---@param WrapperRight string? # Default: ""
---@return string
local function ArrayToString(StringArray, Seperator, WrapperLeft, WrapperRight)
    Seperator = Seperator or " | "
    WrapperLeft = WrapperLeft or ""
    WrapperRight = WrapperRight or ""
    if type(StringArray) == "string" then
        return StringArray
    end

    if type(StringArray) ~= "table" then
        return ""
    end

    local result = ""
    for _, value in ipairs(StringArray) do
        if result ~= "" then
            result = result .. Seperator
        end
        result = result .. WrapperLeft .. value .. WrapperRight
    end
    return result
end

---@param Parameters CommandParam[]
---@param Seperator string? # Default: " | "
---@param WrapperLeft string? # Default: ""
---@param WrapperRight string? # Default: ""
---@return string
local function ParametersToReadableList(Parameters, Seperator, WrapperLeft, WrapperRight)
    if not Parameters then return "" end
    Seperator = Seperator or " "
    WrapperLeft = WrapperLeft or "<"
    WrapperRight = WrapperRight or ">"

    local parameters = ""
    for i, param in ipairs(Parameters) do
        if i > 1 then
            parameters = parameters .. Seperator
        end
        parameters = parameters .. WrapperLeft .. param.Name .. WrapperRight
    end
    return parameters
end

---@param Name string
---@param ValidType string # Type name, see: https://www.lua.org/pil/2.html
---@param Description string?
---@param Required boolean? # Default: false
---@param ValidValues string|string[]|nil
---@return CommandParam
local function CreateCommandParam(Name, ValidType, Description, Required, ValidValues)
    if not Name or Name == "" then
        error('CreateCommandParam: Invalid parameter "Name". Name must be a valid string and can\'t be empty')
    end
    if not ValidType or ValidType == "" then
        error('CreateCommandParam: Invalid parameter "ValidType". ValidType must be a valid type string and can\'t be empty')
    end
    if not Name and type(Name) ~= "table" then
        error('CreateCommandParam: Invalid parameter "ValidValues". ValidValues must be nil or an array of strings')
    end
    Required = Required or false
    if type(ValidValues) == "string" then
        ValidValues = { ValidValues }
    end

    return {
        Name = Name,
        ValidType = ValidType,
        Description = Description,
        Required = Required,
        ValidValues = ValidValues,
    }
end

---Creats a new CommandStruct out of parameters
---@param Aliases table<string>|string
---@param CommandName string
---@param Description string?
---@param Parameters CommandParam|CommandParam[]|nil
---@param Callback CommandFunction?
---@param SettingName string?
---@return CommandStruct # Returns created command
local function CreateCommand(Aliases, CommandName, Description, Parameters, Callback, SettingName)
    Description = Description or ""
    if type(Aliases) == "string" then
        Aliases = { Aliases }
    end
    if type(Aliases) ~= "table" then
        error('CreateCommand: Invalid "CommandNames" parameter')
    end
    if not CommandName then
        error('CreateCommand: Invalid "FeatureName" parameter')
    end
    -- Check if Parameters is an array of tables or a single CommandParam
    if Parameters and Parameters.Name then
        Parameters = { Parameters }
    end

    -- LogDebug("CreateCommand: Name: " .. CommandName .. ", Aliases: " .. ArrayToString(Aliases) .. ", Description: " .. Description .. ", Parameters type: " .. type(Parameters))
    -- if DebugMode and type(Parameters) == "table" then
    --     for index, value in ipairs(Parameters) do
    --         LogDebug(index .. ": " .. value.Name .. ", Required: " .. tostring(value.Required))
    --     end
    -- end

    local commandObject = {
        Aliases = Aliases,
        Name = CommandName,
        Description = Description,
        Parameters = Parameters,
        Function = Callback,
        SettingName = SettingName
    }

    table.insert(CommandsArray, commandObject)
    MapCommand(CommandName, commandObject)
    for i, alias in ipairs(Aliases) do
        MapCommand(alias, commandObject)
    end

    return commandObject
end

---@param Alias string
---@return CommandStruct?
local function GetCommandByAlias(Alias)
    if type(Alias) ~= "string" then return nil end

    return GetCommand(Alias)
end

if DebugMode then
    function PrintCommandsAsMarkdownTable()
        print("------- Markdown Table -----------")
        print("Command | Aliases | Parameters | Description")
        print("------- | ------- | ---------- | -----------")
        for _, command in ipairs(CommandsArray) do
            if command.Function then
                print(string.format("%s | %s | %s | %s", command.Name, ArrayToString(command.Aliases, " \\| "),
                    ParametersToReadableList(command.Parameters, " ", "{", "}"), command.Description))
            end
        end
        print("----------------------------------")
    end

    function PrintCommandsAsBBCode()
        print("-- BBCode --")
        for _, command in ipairs(CommandsArray) do
            if command.Function then
                local parameters = ""
                if command.Parameters and #command.Parameters > 0 then
                    parameters = string.format(" %s ", ParametersToReadableList(command.Parameters))
                end
                print(string.format("[b]%s[/b] [ %s ] {%s} - [font=Georgia]%s[/font]", command.Name,
                    ArrayToString(command.Aliases, " | ", "[font=Arial]", "[/font]"), parameters, command.Description))
            end
        end
        print("----------------------------------")
    end

    function LogCommandsAsMarkdownTable()
        local file = io.open("CommandsAsMarkdown.md", "w")
        if file then
            local content = "Command | Aliases | Parameters | Description\n"
            content = content .. "------- | ------- | ---------- | -----------\n"
            for _, command in ipairs(CommandsArray) do
                if command.Function then
                    content = content .. string.format("%s | %s | %s | %s\n", command.Name, ArrayToString(command.Aliases, " \\| "), ParametersToReadableList(command.Parameters, " ", "{", "}"), command.Description)
                end
            end
            file:write(content)
            return file:close()
        end
    end

    function LogCommandsAsBBCode()
        local file = io.open("CommandsAsBBCode.txt", "w")
        if file then
            local content = ""
            for _, command in ipairs(CommandsArray) do
                if command.Function then
                    local parameters = ""
                    if command.Parameters and #command.Parameters > 0 then
                        parameters = string.format(" %s ", ParametersToReadableList(command.Parameters))
                    end
                    content = content .. string.format("[b]%s[/b] [ %s ] {%s} - [font=Georgia]%s[/font]\n", command.Name, ArrayToString(command.Aliases, " | ", "[font=Arial]", "[/font]"), parameters, command.Description)
                end
            end
            file:write(content)
            return file:close()
        end
    end
end

---
---@param State boolean
---@param CommandName string
---@param OutputDevice FOutputDevice
---@return string StateText
local function PrintCommandState(State, CommandName, OutputDevice)
    local stateText = CommandName .. " "
    if State then
        stateText = stateText .. "Enabled"
    else
        stateText = stateText .. "Disabled"
    end
    WriteToConsole(OutputDevice, stateText)
    return stateText
end

---@param Parameters CommandParam[]
---@return string
local function ParametersToString(Parameters)
    if not Parameters then return "" end

    local parameters = ""
    for _, param in ipairs(Parameters) do
        if parameters ~= "" then
            parameters = parameters .. " "
        end
        parameters = parameters .. "<" .. param.Name .. ">"
        if not param.Required then
            parameters = parameters .. "?"
        end
    end
    return parameters
end

---@param OutputDevice FOutputDevice
---@param Parameters CommandParam[]
local function WriteParametersToConsole(OutputDevice, Parameters)
    if not OutputDevice or not Parameters then return end

    WriteToConsole(OutputDevice, "Parameters breakdown:")
    for i, param in ipairs(Parameters) do
        local name = '"' .. param.Name .. '"'
        if not param.Required then
            name = name .. " (optional)"
        end
        WriteToConsole(OutputDevice, " | Parameter: " .. name)
        WriteToConsole(OutputDevice, "   Type: " .. param.ValidType)
        if param.Description then
            WriteToConsole(OutputDevice, "   Description: " .. param.Description)
        end
        if param.ValidValues then
            WriteToConsole(OutputDevice, "   Valid values:")
            for _, validValue in ipairs(param.ValidValues) do
                WriteToConsole(OutputDevice, "   →" .. validValue)
            end
        end
    end
end

---@param OutputDevice FOutputDevice
---@param Command CommandStruct?
local function WriteCommandToConsole(OutputDevice, Command)
    if not OutputDevice or not Command or not Command.Function then return end

    WriteToConsole(OutputDevice, "Command: " .. Command.Name)
    WriteToConsole(OutputDevice, "Aliases: " .. ArrayToString(Command.Aliases))
    if Command.Description then
        WriteToConsole(OutputDevice, "Description: " .. Command.Description)
    end
    if type(Command.Parameters) == "table" then
        WriteToConsole(OutputDevice, "Parameters: " .. ParametersToString(Command.Parameters))
        WriteParametersToConsole(OutputDevice, Command.Parameters)
    end
    WriteToConsole(OutputDevice, "------------------------------")
end

---@param OutputDevice FOutputDevice
---@param NameOrIndex string|integer
---@return AAbiotic_PlayerCharacter_C? player, string playerName
local function GetPlayerByNameOrIndex(OutputDevice, NameOrIndex)
    local playerIndex = tonumber(NameOrIndex)
    local player = nil
    local playerName = ""
    if playerIndex then
        if playerIndex < 1 then
            WriteErrorToConsole(OutputDevice, "Player's index can't be smaller than 1!")
            return nil, ""
        end
        player, playerName = PlayersManager.GetPlayerByIndex(playerIndex)
        if not player then
            WriteErrorToConsole(OutputDevice, "Couldn't find a player with index " .. playerIndex)
            return nil, ""
        end
    else
        ---@cast NameOrIndex string
        player, playerName = PlayersManager.GetPlayerByName(NameOrIndex)
        if not player then
            WriteErrorToConsole(OutputDevice, "Couldn't find a player with name \"" .. NameOrIndex .. '"')
            return nil, ""
        end
    end
    return player, playerName
end

---@param Parameters string[]
---@param StartIndex integer?
---@return string
local function CombineParameters(Parameters, StartIndex)
    StartIndex = StartIndex or 1
    local locationName = ""
    for i = StartIndex, #Parameters, 1 do
        if i > 1 then
            locationName = locationName .. " "
        end
        locationName = locationName .. Parameters[i]
    end
    return locationName
end

-- Instant Fishing Command
CreateCommand({ "instantfishing", "instfish", "instantfish" }, "Instant Fishing",
    "Makes you instantly finish the fishing minigame with success (junk items are still random). (works as guest)", nil,
    function(self, OutputDevice, Parameters)
        Settings.InstantFishing = not Settings.InstantFishing
        PrintCommandState(Settings.InstantFishing, self.Name, OutputDevice)
        return true
    end,
    "InstantFishing")

-- Set Leyak Cooldown Command
CreateCommand({ "leyakcd", "leyakcooldown", "cdleyak" }, "Leyak Cooldown",
    "Changes Leyak's spawn cooldown in minutes (Default: 15min). The cooldown will be reapplied by the mod automatically each time you start the game. (To disable the command set value to 0 or 15) (host only)",
    CreateCommandParam("minutes", "number", "Amount a minutes between each Leyak spawn"),
    function(self, OutputDevice, Parameters)
        local cooldownInMin = nil
        if Parameters and #Parameters > 0 then
            cooldownInMin = tonumber(Parameters[1])
        end
        if type(cooldownInMin) ~= "number" then
            local leyakDirectorComponent = AFUtils.GetLeyakDirectorComponent()
            if IsValid(leyakDirectorComponent) then
                WriteToConsole(OutputDevice, self.Name .. ": Current cooldown: " .. (leyakDirectorComponent.LeyakCooldown / 60) .. " minutes")
            end
            WriteToConsole(OutputDevice, self.Name .. ': To change it write: "leyakcd (cooldown value in minutes here)"')
            return true
        end

        if cooldownInMin >= 525600000 then
            WriteErrorToConsole(OutputDevice, self.Name .. ": Invalid cooldown value!")
            WriteErrorToConsole(OutputDevice, self.Name .. ': The value must be lower than 525600000 (minutes)')
            return true
        end
        if cooldownInMin > 0  then
            WriteToConsole(OutputDevice, "Execute " .. self.Name .. " command with value: " .. cooldownInMin)
            Settings.LeyakCooldown = cooldownInMin * 60
        else
            WriteToConsole(OutputDevice, self.Name .. " disabled, set back to default value.")
            Settings.LeyakCooldown = 0
        end

        return true
    end,
    "LeyakCooldown")

-- Trap Leyak Command
CreateCommand({ "trapleyak", "containleyak" }, "Trap Leyak", "Trap's Leyak in the next possible Containment Unit. (host only)", nil,
    function(self, OutputDevice, Parameters)
        local leyakContainments = FindAllOf("Deployed_LeyakContainment_C") ---@cast leyakContainments ADeployed_LeyakContainment_C[]?
        if leyakContainments then
            LogDebug("Trap Leyak Command: leyakContainments:",#leyakContainments)
            -- Check if Leyak is already trapped
            for _, leyakContainment in ipairs(leyakContainments) do
                if IsValid(leyakContainment) and not leyakContainment.DeployableDestroyed and leyakContainment.ContainsLeyak == AFUtils.LeyakRowName then
                    WriteErrorToConsole(OutputDevice, "Leyak is already trapped")
                    return false
                end
            end
            for _, leyakContainment in ipairs(leyakContainments) do
                if IsValid(leyakContainment) and not leyakContainment.DeployableDestroyed and leyakContainment.ContainsLeyak:GetComparisonIndex() == 0 then
                    if AFUtils.TrapLeyak(leyakContainment) then
                        WriteToConsole(OutputDevice, "Leyak was trapped successfully.")
                        return true
                    else
                        WriteErrorToConsole(OutputDevice, "Failed to trap Leyak.")
                        return false
                    end
                end
            end
        end
        WriteErrorToConsole(OutputDevice, "Couldn't find a deployed Containment Unit. Have you built one?")
        return false
    end)

-- Free Leyak Command
CreateCommand({ "freeleyak" }, "Free Leyak", "Free Leyak from a Containment Unit. (host only)", nil,
    function(self, OutputDevice, Parameters)
        local leyakContainments = FindAllOf("Deployed_LeyakContainment_C") ---@cast leyakContainments ADeployed_LeyakContainment_C[]?
        if leyakContainments then
            LogDebug("Free Leyak Command: leyakContainments:", #leyakContainments)
            -- Check if Leyak is already trapped
            for _, leyakContainment in ipairs(leyakContainments) do
                if IsValid(leyakContainment) and not leyakContainment.DeployableDestroyed and leyakContainment.ContainsLeyak == AFUtils.LeyakRowName then
                    if AFUtils.FreeLeyak(leyakContainment) then
                        WriteToConsole(OutputDevice, "Leyak was freed successfully")
                        return true
                    else
                        WriteErrorToConsole(OutputDevice, "Failed to free Leyak")
                        return false
                    end
                end
            end
            WriteErrorToConsole(OutputDevice, "None of deployed Containment Units contain Leyak")
            return false
        end
        WriteErrorToConsole(OutputDevice, "Couldn't find a deployed Containment Unit.")
        return false
    end)

-- Set Krasue Cooldown Command
CreateCommand({ "krasuecd", "rasuecooldown", "cdrasue" }, "Krasue Cooldown",
    "Changes Krasue's spawn cooldown in minutes (Default: 10min). The cooldown will be reapplied by the mod automatically each time you start the game. (To disable the command set value to 0 or 10) (host only)",
    CreateCommandParam("minutes", "number", "Amount a minutes between each Krasue spawn"),
    function(self, OutputDevice, Parameters)
        local cooldownInMin = nil
        if Parameters and #Parameters > 0 then
            cooldownInMin = tonumber(Parameters[1])
        end
        if type(cooldownInMin) ~= "number" then
            local directorComponent = AFUtils.GetKrasueDirectorComponent()
            if IsValid(directorComponent) then
                WriteToConsole(OutputDevice, self.Name .. ": Current cooldown: " .. (directorComponent.LeyakCooldown / 60) .. " minutes")
            end
            WriteToConsole(OutputDevice, self.Name .. ': To change it write: "krasuecd (cooldown value in minutes here)"')
            return true
        end

        if cooldownInMin >= 525600000 then
            WriteErrorToConsole(OutputDevice, self.Name .. ": Invalid cooldown value!")
            WriteErrorToConsole(OutputDevice, self.Name .. ': The value must be lower than 525600000 (minutes)')
            return true
        end
        if cooldownInMin > 0  then
            WriteToConsole(OutputDevice, "Execute " .. self.Name .. " command with value: " .. cooldownInMin)
            Settings.KrasueCooldown = cooldownInMin * 60
        else
            WriteToConsole(OutputDevice, self.Name .. " disabled, set back to default value.")
            Settings.KrasueCooldown = 0
        end

        return true
    end,
    "KrasueCooldown")

-- Trap Krasue Command
CreateCommand({ "trapkrasue", "containkrasue" }, "Trap Krasue", "Trap's Krasue in the next possible Containment Unit. (host only)", nil,
    function(self, OutputDevice, Parameters)
        local leyakContainments = FindAllOf("Deployed_LeyakContainment_C") ---@cast leyakContainments ADeployed_LeyakContainment_C[]?
        if leyakContainments then
            LogDebug("Trap Krasue Command: leyakContainments:",#leyakContainments)
            -- Check if Leyak is already trapped
            for _, leyakContainment in ipairs(leyakContainments) do
                if IsValid(leyakContainment) and not leyakContainment.DeployableDestroyed and leyakContainment.ContainsLeyak == AFUtils.KrasueRowName then
                    WriteErrorToConsole(OutputDevice, "Krasue is already trapped")
                    return false
                end
            end
            for _, leyakContainment in ipairs(leyakContainments) do
                if IsValid(leyakContainment) and not leyakContainment.DeployableDestroyed and leyakContainment.ContainsLeyak:GetComparisonIndex() == 0 then
                    if AFUtils.TrapKrasue(leyakContainment) then
                        WriteToConsole(OutputDevice, "Krasue was trapped successfully.")
                        return true
                    else
                        WriteErrorToConsole(OutputDevice, "Failed to trap Krasue.")
                        return false
                    end
                end
            end
        end
        WriteErrorToConsole(OutputDevice, "Couldn't find a deployed Containment Unit. Have you built one?")
        return false
    end)

-- Free Krasue Command
CreateCommand({ "freekrasue" }, "Free Krasue", "Free Krasue from a Containment Unit. (host only)", nil,
    function(self, OutputDevice, Parameters)
        local leyakContainments = FindAllOf("Deployed_LeyakContainment_C") ---@cast leyakContainments ADeployed_LeyakContainment_C[]?
        if leyakContainments then
            LogDebug("Free Krasue Command: leyakContainments:", #leyakContainments)
            -- Check if Krasue is already trapped
            for _, leyakContainment in ipairs(leyakContainments) do
                if IsValid(leyakContainment) and not leyakContainment.DeployableDestroyed and leyakContainment.ContainsLeyak == AFUtils.KrasueRowName then
                    if AFUtils.FreeKrasue(leyakContainment) then
                        WriteToConsole(OutputDevice, "Krasue was freed successfully")
                        return true
                    else
                        WriteErrorToConsole(OutputDevice, "Failed to free Krasue")
                        return false
                    end
                end
            end
            WriteErrorToConsole(OutputDevice, "None of deployed Containment Units contain Krasue")
            return false
        end
        WriteErrorToConsole(OutputDevice, "Couldn't find a deployed Containment Unit.")
        return false
    end)

-- Journal Entry Unlocker Command
CreateCommand({ "journalentry", "journalunlocker", "entryunlocker" }, "Journal Entry Unlocker",
    "After enabling, the Journal Entry you click on will be unlocked. (works as guest)", nil,
    function(self, OutputDevice, Parameters)
        Settings.JournalEntryUnlocker = not Settings.JournalEntryUnlocker
        PrintCommandState(Settings.JournalEntryUnlocker, self.Name, OutputDevice)
        return true
    end,
    "JournalEntryUnlocker")

-- Master Key Command
CreateCommand({ "masterkey", "key", "keys", "opendoor", "opendoors" }, "Master Key",
    "Allows to open all doors (host only)", nil,
    function(self, OutputDevice, Parameters)
        Settings.MasterKey = not Settings.MasterKey
        PrintCommandState(Settings.MasterKey, self.Name, OutputDevice)
        return true
    end,
    "MasterKey")

-- Set Weather Command
CreateCommand({ "setweather", "weather", "weatherevent" }, "Set Weather",
    "Triggers weather event (host only)",
    CreateCommandParam("weather", "string", "", false, { "None", "Fog", "RadLeak", "Spores", "ColdSnap", "ColdSnap", " Blackout", "BlackFog" }),
    function(self, OutputDevice, Parameters)
        if CheckHasNoAuthority(OutputDevice) then
            return false
        end

        if not Parameters or #Parameters < 1 then
            local weatherNames = ""
            for i, rowName in ipairs(WeatherManager.GetAllWeatherEventNames()) do
                if i > 1 then
                    weatherNames = weatherNames .. ", "
                end
                weatherNames = weatherNames .. rowName
            end
            WriteToConsole(OutputDevice, "Posible weather events: " .. weatherNames)
            return false
        end

        local weather = WeatherManager.TriggerWeatherEvent(Parameters[1])
        if weather then
            local message = "Set weather to " .. weather
            WriteToConsole(OutputDevice, message)
            AFUtils.ClientDisplayWarningMessage(message, AFUtils.CriticalityLevels.Green)
        else
            WriteErrorToConsole(OutputDevice, "Couldn't find any weather events with name: " .. Parameters[1])
        end

        return true
    end)

 
CreateCommand({ "playerlist", "listplayers", "players" }, "Player List",
    "Prints a list of all players in the game. Format: (index): (player name)", nil,
    function(self, OutputDevice, Parameters)
        local playerNames = PlayersManager.GetPlayerNames()
        if playerNames and #playerNames > 0 then
            WriteToConsole(OutputDevice, string.format("-- Players (%d) --", #playerNames))
            for index, name in ipairs(playerNames) do
                WriteToConsole(OutputDevice, string.format(" %d: %s", index, name))
            end
        end

        return true
    end)

CreateCommand({ "toplayer", "teleportto", "tpto" }, "Teleport To Player", "Teleports to a player based on their name or index (host only)",
    CreateCommandParam("name/index", "string", "Name or index of a player"),
    function(self, OutputDevice, Parameters)
        if not Parameters or #Parameters < 1 then
            WriteErrorToConsole(OutputDevice, "Invalid number of parameters!")
            WriteToConsole(OutputDevice, "The command requires part of player's name or his index. e.g. 'tpto igromanru'")
            WriteToConsole(OutputDevice, "Use the player list command to get a list of all players in the lobby. e.g. 'players'")
            return true
        end
        
        local player, playerName = GetPlayerByNameOrIndex(OutputDevice, Parameters[1])
        if player then
            local myPlayer = AFUtils.GetMyPlayer()
            WriteToConsole(OutputDevice, "Teleporting to \"" .. playerName .. '"')
            if not AFUtils.TeleportPlayerToPlayer(myPlayer, player, true) then
                WriteErrorToConsole(OutputDevice, "Teleportation failed, are you the host?")
            end
        end

        return true
    end)
